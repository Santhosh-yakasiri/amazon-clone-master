import React from "react";
import OrderDisplay from "./OrderDisplay";

function OrderContainer(props) {
  return <OrderDisplay {...props} />;
}

export default OrderContainer;
