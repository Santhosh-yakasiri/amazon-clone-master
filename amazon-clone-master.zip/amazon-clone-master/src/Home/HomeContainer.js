import React from "react";
import HomeDisplay from "./HomeDisplay";

function HomeContainer() {
  return <HomeDisplay />;
}

export default HomeContainer;
